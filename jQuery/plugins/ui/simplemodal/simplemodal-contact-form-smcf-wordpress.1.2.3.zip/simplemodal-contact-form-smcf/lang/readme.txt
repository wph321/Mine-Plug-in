If you are interested in translating SMCF, use smcf.pot as a template to create a po file for the new translation file.

The resulting translated file should be named with the following format:
- smcf-
- ISO 639 language code (lowercase)
- an underscore
- ISO 3166-1 alpha-2 country code (uppercase) 
- .mo

So for an Italian translation, the file name would be smcf-it_IT.mo

Please send the translated file to simplemodal@ericmmartin.com.

Thanks!